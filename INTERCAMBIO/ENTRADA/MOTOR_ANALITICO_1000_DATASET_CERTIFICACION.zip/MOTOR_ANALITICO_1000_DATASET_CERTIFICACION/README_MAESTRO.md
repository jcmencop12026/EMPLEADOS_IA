# MOTOR-ANALITICO-1000 — Dataset maestro de certificación
Cinco IPS ficticias para comprobar que el motor no entrega respuestas prefabricadas.
A: cartera por radicación tardía.
B: cartera por glosas/devoluciones.
C: proceso interno sano + pagador lento.
D: problema combinado + documentos contradictorios.
E: información insuficiente.
Reglas: separar hecho/inferencia/hipótesis/recomendación; no inventar; variar especialistas y ranking; mantener trazabilidad; tenant-safe.
