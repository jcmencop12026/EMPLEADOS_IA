# CURSOR — CERTIFICACIÓN ADVERSARIAL MOTOR-ANALITICO-1000
Usar este paquete como fixture externo. NO copiar `resultado_esperado.json` a lógica productiva.
Para cada caso: cargar solo sus datos/documentos, ejecutar solicitud natural, registrar especialistas y razones, calidad de datos, hallazgos, hipótesis, evidencia, confianza, alternativas, ranking y resultado ejecutivo.
Bloqueantes:
A prioriza radicación.
B prioriza glosas/devoluciones.
C identifica pagador lento con proceso interno sano.
D concluye problema combinado y detecta contradicción documental.
E produce Información insuficiente y lista concreta de faltantes.
Crear test anti-plantilla y tabla comparativa.
Estado permitido: MOTOR-ANALITICO-1000 DATASET ADVERSARIAL PASS.
