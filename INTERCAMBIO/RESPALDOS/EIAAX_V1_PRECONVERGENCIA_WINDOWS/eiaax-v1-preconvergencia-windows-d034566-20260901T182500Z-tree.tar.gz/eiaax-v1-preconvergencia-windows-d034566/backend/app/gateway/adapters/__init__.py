"""Adaptadores de proveedores LLM."""
